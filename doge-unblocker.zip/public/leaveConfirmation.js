window.onbeforeunload = function(e) {  return "Do you want to exit this page?";};
console.log("leaveConfirmation.js activated.");
