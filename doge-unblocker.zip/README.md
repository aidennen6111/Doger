<h2>If you forked this repository and would like to recieve updates, please sync your repository or re-fork it.</h2>
<h2>Doge Unblocker</h3>
<p>Doge Unblocker is a blazing fast proxy service used to bypass internet restrictions. Made by students, for students.</p>



<h2>Link Deployment</h2>
<h3>Local Hosting (Requires Git and Node.js installed):</h3>
<code>git clone https://github.com/dogeproxy/doge-unblocker</code>
<br>
<code>cd doge-unblocker</code>
<br>
<code>npm start</code>
<h3>Free Services</h3>
<a href="https://render.com/deploy?repo=https://github.com/dogeproxy/doge-unblocker">
<img src="https://raw.githubusercontent.com/BinBashBanana/deploy-buttons/main/buttons/remade/render.svg"></img></a>
<a href="https://app.cyclic.sh/api/app/deploy/dogeproxy/doge-unblocker">
<img src="https://camo.githubusercontent.com/607221ca4be547dd929fca7c997a93dfaf1f7b06a1baacaf25b44cf5405c9f91/68747470733a2f2f62696e6261736862616e616e612e6769746875622e696f2f6465706c6f792d627574746f6e732f627574746f6e732f72656d6164652f6379636c69632e737667"></img></a>
<p>If you want to recieve updates from Doge Unblocker on <strong>Render,</strong> please update it by clicking <code>Manual Deploy > Latest Commit</code></p>


<br>
<h1></h1>
<h3>Join our community for more proxy links!</h3>

[![Join us on Discord](https://invidget.switchblade.xyz/sWPHCdxCPU?theme=dark)](https://discord.gg/sWPHCdxCPU)




